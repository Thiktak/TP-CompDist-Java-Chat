

/**
 *
 * @author Georges OLIVARES <dev@olivares-georges.fr>
 */
public class TPCompDistJavaChat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
