
/**
 *
 * @author Georges OLIVARES <dev@olivares-georges.fr>
 */
public interface EventChatMessage {

    public void actionPerformed(ChatClient client, String msg);
}
